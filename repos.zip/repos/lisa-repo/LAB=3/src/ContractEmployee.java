public class ContractEmployee extends Employee {
	
	public static int count;
	private Contractor con;
	public int noOfHours;
	public Date doj;
	public ContractEmployee(int noOfHours,Date doj){
		count=count+1;
		this.noOfHours=noOfHours;
		this.doj=doj;
	}
	public double getSalary(){
		salary =  con.rate * noOfHours;
		return salary;	
	}
	public Contractor getContractor() {
		return con;
	}
	public void setContractor(Contractor contractor) {
		this.con = contractor;
	}	
	public void displayContract(){
		System.out.println("Salary is " +getSalary()+"\nDoj:"+doj);
		System.out.println("---------------------------------------------");
	}
	
}
