package com.cg;

public class ProductPK {
	
	int id;
	Double price;
	public ProductPK(int id, Double price) {
		super();
		this.id = id;
		this.price = price;
	}
	
	public int getId() {
		return id;
	}
	
	public Double getPrice() {
		return price;
	}

	@Override
	public int hashCode() {
		/*final int prime = 31;
		int result = 1;
		result = prime * result + id;
		result = prime * result + ((price == null) ? 0 : price.hashCode());
		return result;*/
		return price.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		/*if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProductPK other = (ProductPK) obj;
		if (id != other.id)
			return false;
		if (price == null) {
			if (other.price != null)
				return false;
		} else if (!price.equals(other.price))
			return false;
		return true;*/
		boolean flag;
		flag = ((this.id == ((ProductPK)obj).id) && (this.price == ((ProductPK)obj).price));
		return flag;
	}
	@Override
	public String toString() {
		return "ProductPK [id=" + id + ", price=" + price + "]";
	}
}
