
public class Entry {
	public static void main(String[] args)
    {
		LinkedList list = new LinkedList(); 
		list.display();
		list.add(2);
		list.display();
		list.add(5);
		list.display();
		/*list.add(4);
		list.display();
		list.add(10);
		list.display();*/
    }
}
