import static java.lang.System.out;

class Entry{
	public static void main(String[] args){
		out.print("Hello, world!");
	}
}