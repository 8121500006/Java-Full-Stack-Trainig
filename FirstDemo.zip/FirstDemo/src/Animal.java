public class Animal
{
 
	public void eat()
	{
			System.out.print("Eat");
	}
	public void sleep()
	{
			System.out.print("Sleeping");
	}
	
}
class Feline extends Animal
	{
		public void eat()
		{
			System.out.print("Eat");
		}
		public void sleep()
		{
			System.out.print("Sleeping");
		}
	}
