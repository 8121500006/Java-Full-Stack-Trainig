package demojpa.sprjpademo;
import javax.persistence.*;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Repository(value="ab")
public class EmployeeService {
	@PersistenceContext
	protected EntityManager em;

	/*public EmployeeService(EntityManager em){
		this.em=em;
	}*/
	@Transactional
	public Employee createEmployee(int id,String name,int salary, Address address, Department department){
		//em.getTransaction().begin();
		Employee emp = new Employee(id);
        	
		emp.setName(name);
		emp.setSalary(salary);
		emp.setAddress(address);
		emp.setDepartment(department);
		//em.getTransaction().commit();
		em.merge(emp);
		return emp;
	}

	public void removeEmployee(int id){
		Employee emp = findEmployee(id);
		if(emp !=null){
			em.remove(emp);
		}
	}

	public Employee raiseEmployeeSalary(int id, int raise){
		Employee emp = findEmployee(id);
		if(emp !=null){
			emp.setSalary(emp.getSalary()+raise);
		}
		return emp;
	}

	public List<Employee> findAllEmployees(){
		TypedQuery<Employee> query = em.createQuery("Select e from Employee e",Employee.class);
		return query.getResultList();

	}
	public Employee findEmployee(int id) {
		// TODO Auto-generated method stub
		return em.find(Employee.class, id);
	}
	public Department createDepartment(int id, String name){
		
		Department dept = new Department(id,name);
		
		
		return dept;
	}

	/*public Department setEmployeesOnDepartment(int id, List<Employee>employees){
		Department dept = findDepartment(id);
		dept.setEmployees(employees);
		em.persist(dept);
		return dept;
	}*/
	public Department findDepartment(int id){
		return em.find(Department.class, id);
	}

}
