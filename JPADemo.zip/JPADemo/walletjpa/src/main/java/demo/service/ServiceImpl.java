package demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import demo.beans.Customer;
import demo.beans.Wallet;
import demo.repo.WalletRepo;



@Service(value="service")
public class ServiceImpl implements WalletService {
	@Autowired
	private WalletRepo repo;
	
	
	/*public Customer createAccount(Customer c) {
		Customer c1 = repo.save(c);	
		return c1;
		
	}*/
	
	@Transactional
		public Customer createAccount(int id, String name, String mobile, float amount) {
				// Method to create new account
				Customer customer = new Customer();
				Wallet wallet = new Wallet(id,amount);
				customer.setId(id);
				customer.setName(name);
				customer.setMobileNumber(mobile);
				/*wallet.setBalance(amount);
				*/
				customer.setWallet(wallet);
				repo.save(customer);
				return customer;
			} 
		 
	

	/*public Customer depositAmount(int id, float depositAmount) {
		// TODO Auto-generated method stub
		Customer customer = repo.findOne(id);
		Wallet wallet = em.find(Wallet.class, id);
		//Wallet wallet = customer.getWallet();
		float amount = wallet.getBalance() + depositAmount;
		wallet.setBalance(amount);
		customer.setWallet(wallet);
		em.persist(customer);
		return customer;
	}


	public Customer withDrawAmount(int id, float withDrawAmount) {
		// TODO Auto-generated method stub
		Customer customer = repo.findOne(id);
		Wallet wallet = em.find(Wallet.class, id);
		float amount = wallet.getBalance() - withDrawAmount;
		wallet.setBalance(amount);
		customer.setWallet(wallet);
		//repo.save(customer);
		em.persist(customer);
		return customer;
	}*/
		
	public Customer showBalance(int id) {
		// TODO Auto-generated method stub
		return repo.findById(id);
	}

	@Transactional
	@Override
	public boolean depositAmount(int id, float depositAmount) {
		Customer customer = repo.findById(id);
		Wallet wallet = customer.getWallet();
		float amount = wallet.getBalance() + depositAmount;
		wallet.setBalance(amount);
		customer.setWallet(wallet);
		repo.save(customer);
		return true;
	}

	@Transactional
	@Override
	public boolean withDrawAmount(int id, float withDrawAmount) {
		Customer customer = repo.findById(id);
		Wallet wallet = customer.getWallet();
		if(wallet.getBalance() >= withDrawAmount)
		{
			float amount = wallet.getBalance() - withDrawAmount;
			wallet.setBalance(amount);
			customer.setWallet(wallet);
			repo.save(customer);
			return true;
		}
		return false;
	}

	
	
	

}
