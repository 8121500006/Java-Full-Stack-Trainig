package demojpa.temporaldemo;


import javax.persistence.*;


@Embeddable
public class Address {
 
private String line;
public Address() {
	//super();
}
public Address(int id, String line) {
	super();
	//this.id = id;
	this.line = line;
}

public String getLine() {
	return line;
}
public void setLine(String line) {
	this.line = line;
}

}
