package demojpa.sprjpacc;



import org.springframework.context.support.GenericXmlApplicationContext;


public class EmployeeTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("beanconfig.xml");
		
    	EmployeeService s = ctx.getBean("service", EmployeeService.class);	
		
		Address address1 = new Address(1, "TalwadeGaon,Pune");
		Department dept1 = new Department(1, "Timepass");
		Employee emp1 = new Employee(50948,"adi",6000,address1);
		emp1.setDepartment(dept1);
		System.out.print(s.createEmployee(emp1));
		System.out.println(s.findEmployee(50948));
		
	}

}

