package demojpa.sprjpacc;

public interface EmployeeService {
	public Employee createEmployee(Employee e);
	public Employee findEmployee(int id);
}
