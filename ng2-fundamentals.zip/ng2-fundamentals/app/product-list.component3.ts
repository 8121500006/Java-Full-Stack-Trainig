import { ProductService} from './product-service';
import {Component} from '@angular/core';
@Component({
moduleId: module.id,
selector: 'pm-products3',
templateUrl: './product-list.component3.html',
providers: [ProductService]
})
export class ProductListComponent3{
    private _productService;
    constructor(productService: ProductService) {
    this._productService = productService;
    }
    imageWidth: number = 50;
imageMargin: number = 2;
showImage: boolean = false;

toggleImage(): void {
    this.showImage = !this.showImage;
}
}