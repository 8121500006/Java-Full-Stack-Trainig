"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var ProductListComponent = (function () {
    function ProductListComponent() {
        this.pageTitle = 'Product List';
        this.products = [
            {
                "productId": 2,
                "productName": "Garden Cart",
                "productCode": "GDN-0023",
                "releaseDate": "March 18, 2016",
                "description": "15 gallon capacity rolling garden cart",
                "price": 32.99,
                "starRating": "4.2",
                "imageUrl": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRKliMnjp-h6sFAFTVhPJu-T1CG27AMDioUCmhqfDXi8khvnmtUwA"
            },
            {
                "productId": 5,
                "productName": "Hammer",
                "productCode": "TBX-0048",
                "releaseDate": "May 21, 2016",
                "description": "Curved claw steel hammer",
                "price": 8.9,
                "starRating": 4.8,
                "imageUrl": "https://orig00.deviantart.net/94e5/f/2012/032/b/a/glowing_thor_hammer_background_by_kalel7-d4obpt2.jpg"
            },
            {
                "productId": 55,
                "productName": "Thor",
                "productCode": "TBX-0148",
                "releaseDate": "May 21, 2016",
                "description": "Curved claw steel hammer",
                "price": 10,
                "starRating": 4.9,
                "imageUrl": "https://lumiere-a.akamaihd.net/v1/images/file_5a756e76.jpeg?width=1200&region=0%2C0%2C2000%2C2000"
            }
        ];
        //inside Product-list.component
        this.imageWidth = 50;
        this.imageMargin = 2;
        this.showImage = false;
        this.filteredProducts = this.products;
        this._listFilter = 'Cart';
    }
    ProductListComponent.prototype.toggleImage = function () {
        this.showImage = !this.showImage;
    };
    Object.defineProperty(ProductListComponent.prototype, "listFilter", {
        get: function () {
            return this._listFilter;
        },
        set: function (value) {
            console.log(value);
            this._listFilter = value;
            this.filteredProducts =
                this.listFilter ? this.performFilter(this.listFilter)
                    : this.products;
        },
        enumerable: true,
        configurable: true
    });
    ProductListComponent.prototype.performFilter = function (filterBy) {
        filterBy = filterBy.toLocaleLowerCase();
        return this.products.filter(function (product) {
            return product.productName.toLocaleLowerCase().indexOf(filterBy)
                !== -1;
        });
    };
    return ProductListComponent;
}());
ProductListComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'pm-products',
        templateUrl: './product-list.component.html'
    }),
    __metadata("design:paramtypes", [])
], ProductListComponent);
exports.ProductListComponent = ProductListComponent;
//# sourceMappingURL=product-list.component.js.map