import { NgModule} 
from '@angular/core'

import { BrowserModule } 
from '@angular/platform-browser'

import {EventsAppComponent} 
from './events-app-component'
import { eventapp1 } from './eventapp1';
import {ProductListComponent3} 
from './product-list.component3'

import { FormsModule } from '@angular/forms';

@NgModule({
    declarations: [EventsAppComponent,eventapp1,ProductListComponent3],
    imports: [BrowserModule, FormsModule],
    bootstrap: [EventsAppComponent, eventapp1,ProductListComponent3]
    
})

export class AppModule{
}