import {Component} from '@angular/core'

@Component({
    selector: 'events-app',
    template: '<h1>Hello , {{name}}, Bharath Ane Neanu</h1> <h2>  <p> Musali Thata mudatha muriseapoyenea gudisea paka guddi dheepam veligipoyenea racha banda pakkanunna ramulori gudlogantaa ambaranga sambaranga mogeanea....... </h2>'
})

export class EventsAppComponent{
     name:  string = "World!";
}