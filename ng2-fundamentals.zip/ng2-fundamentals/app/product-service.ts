import { Injectable } from '@angular/core';

import { IProduct } from './product';

@Injectable()
export class ProductService {

    getProducts(): IProduct[] {
        return [
            {
                "productId": 2,
                "productName": "Garden Cart",
                "productCode": "GDN-0023",
                "releaseDate": "March 18, 2016",
                "description": "15 gallon capacity rolling garden cart",
                "price": 32.99,
                "starRating": 4.2,
                "imageUrl": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRKliMnjp-h6sFAFTVhPJu-T1CG27AMDioUCmhqfDXi8khvnmtUwA"
            },
            {
                "productId": 5,
                "productName": "Hammer",
                "productCode": "TBX-0048",
                "releaseDate": "May 21, 2016",
                "description": "Curved claw steel hammer",
                "price": 8.9,
                "starRating": 4.8,
                "imageUrl": "https://orig00.deviantart.net/94e5/f/2012/032/b/a/glowing_thor_hammer_background_by_kalel7-d4obpt2.jpg"
            },
            {
                "productId": 10,
                "productName": "Video Game Controller",
                "productCode": "GMG-0042",
                "releaseDate": "October 15, 2015",
                "description": "Standard two-button video game controller",
                "price": 35.95,
                "starRating": 4.6,
                "imageUrl": "http://openclipart.org/image/300px/svg_to_png/120337/xbox-controller_01.png"
            },
            {
            "productId": 55,
            "productName": "Thor",
            "productCode": "TBX-0148",
            "releaseDate": "May 21, 2016",
            "description": "Curved claw steel hammer",
            "price": 10,
            "starRating": 4.9,
            "imageUrl": "https://lumiere-a.akamaihd.net/v1/images/file_5a756e76.jpeg?width=1200&region=0%2C0%2C2000%2C2000"
            }
        ];
    }
}
