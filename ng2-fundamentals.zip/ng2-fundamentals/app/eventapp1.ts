import {Component} from '@angular/core'

@Component({
    selector: 'events-app1',
    template: '<h1>NARUTO</h1> '
})
export class eventapp1{
    name:  string = "World!";
}