package demo.client;

import java.util.HashMap;
import java.util.Map;

import demo.beans.Customer;
import demo.repo.WalletRepo;
import demo.repo.RepositoryImpl;
import demo.service.WalletService;
import demo.service.ServiceImpl;

public class Client {
	public static void main(String[] args) {
		Map<String,Customer> data=new HashMap<>();
		WalletRepo repo=new RepositoryImpl(data);
		WalletService service=new ServiceImpl(repo);
	
		
		/*service.createAccount("Annapurnayya", "1234567891", 80000);
		service.createAccount("Aditya", "2345678911", 80000);
		service.createAccount("Sri", "3456789112", 80000);
		service.createAccount("Sarvazna", "4567891123", 80000);
		service.createAccount("Madduri", "5678911234", 80000);*/
	 	System.out.println(service.showBalance("1234567891"));
	
		
	
		/*service.deposit("1234567891", 1000);
		System.out.println(service.showBalance("1234567891"));*/
		service.withDraw("1234567891", 12000);
		System.out.println(service.showBalance("1234567891"));
		
		
	}

}
