package demo.repo;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;

import demo.beans.Customer;
import demo.beans.Wallet;

public class RepoImpl implements WalletRepo{
	Map<String,Customer> data;

	public RepoImpl(Map<String, Customer> data2) {
		// TODO Auto-generated constructor stub
	data=data2;
	}


	public boolean save(Customer c) {
	/*	data.put(c.getMobileNumber(),c);
		
		return true;*/
		int walletid=0;
		float balance= c.getWallet().getBalance();
		String name=c.getName();
		String mobileNumber=c.getMobileNumber();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:8080/test");  
			Statement stmt=con.createStatement();  
			stmt.executeUpdate("insert into Wallet(balance) values("+balance+")"); 
			ResultSet rs=stmt.executeQuery("select walletid from wallet where balance="+balance+"");
			while(rs.next())
				walletid=rs.getInt("walletid");
			stmt.executeUpdate("insert into Customer(name,mobileNumber,walletid) values('"+name+"','"+mobileNumber+"',"+walletid+")");
			System.out.println("Customer is created");

			con.close(); 
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		return true;
	}


	public Customer findOne(String mobileNumber) {
		
		//return data.get(mobileNumber);
		Customer customer=new Customer(); 
		Wallet wallet=new Wallet();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3309/test");  
			Statement stmt=con.createStatement();


			ResultSet rs=stmt.executeQuery("select customer.name,customer.mobileNumber,wallet.balance from customer INNER JOIN wallet ON wallet.walletid=customer.walletid where mobilenumber='"+mobileNumber+"'");

			while(rs.next())
			{
				Float balance=rs.getFloat("balance");
				String name1 = rs.getString("name");
				String mobileNumber1=rs.getString("mobileNumber");
				customer.setName(name1);
				customer.setMobileNumber(mobileNumber1);
				wallet.setBalance(balance);
				customer.setWallet(wallet);
			}

			con.close();


		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return customer;
	}


	public boolean update(Customer c) {
		// TODO Auto-generated method stub
		//return false;
		float balance= c.getWallet().getBalance();
		String mobileNumber=c.getMobileNumber();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3309/test");  
			
		String sql="update customer inner join wallet on wallet.walletid=customer.walletid set wallet.balance =? where mobileNumber=?";
		java.sql.PreparedStatement stmt=con.prepareStatement(sql);
		stmt.setDouble(1,balance);
		stmt.setString(2, mobileNumber);			
		stmt.executeUpdate();

			con.close();


		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return true;

	}

	
	
	

}
