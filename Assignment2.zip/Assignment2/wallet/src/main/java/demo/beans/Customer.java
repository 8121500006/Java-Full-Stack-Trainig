package demo.beans;

import javax.persistence.*;

@Entity
public class Customer {
	@Id private int id;	
	private String mobileNumber;
	private String name;
	@OneToOne(cascade=CascadeType.ALL)
	private Wallet wallet;
	public String getName() {
		return name;
	}
	public Customer() {
	}
	
	
	public Customer(int id) {
		super();
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public Wallet getWallet() {
		return wallet;
	}
	public void setWallet(Wallet wallet) {
		this.wallet = wallet;
	}
	public String toString()
	{
		return name+" "+mobileNumber+" "+" "+wallet.getBalance();
	}
}
