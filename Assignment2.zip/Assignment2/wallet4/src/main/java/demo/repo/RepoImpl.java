package demo.repo;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;


import java.sql.*;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import demo.beans.Customer;
@Repository
public class RepoImpl implements WalletRepo
{

	//@Resource(name = "data")
	private Map<String,Customer> data;
	public RepoImpl(Map<String, Customer> data2) {
		// TODO Auto-generated constructor stub
	data=data2;
	}
	//	TODO 1	Load JDBC Driver in main memory

	
	public boolean save(Customer c) {
		// data.put(c.getMobileNumber(),c);
		try {
		String jdbcDriver="com.mysql.jdbc.Driver";
		Class.forName(jdbcDriver);


	String jdbcURL = "jdbc:mysql://localhost:3306/test";

	Connection dbConnection = DriverManager.getConnection(jdbcURL);
	Statement stmt=dbConnection.createStatement();
		Statement selectStatement = dbConnection.createStatement(
				ResultSet.TYPE_FORWARD_ONLY,ResultSet.CONCUR_READ_ONLY);

		String insertQuery, insertQuery1;
		int wallet_id = 0;
		//		Dynamic SQL Query
		insertQuery1 = "insert into Wallet (`balance`) values(?)";

		PreparedStatement insertStatement = dbConnection.prepareStatement(insertQuery1);
		float tempbalance = c.getWallet().getBalance();
		//float Tempbalance = 1000;
		insertStatement.setFloat(1, tempbalance);

		ResultSet rs=stmt.executeQuery("select walletid from Wallet where balance='\"+tempbalance+\"'");
		while(rs.next())
		{
		     wallet_id=rs.getInt("walletid");
		insertQuery = "insert into Customer (`name`, `mobileNumber`, `walletid`) values(?,?,?)";

		PreparedStatement insertStatement2 = dbConnection.prepareStatement(insertQuery);

		insertStatement2.setString(1, c.getName());
		insertStatement2.setString(2, c.getMobileNumber());
		insertStatement2.setInt(3, wallet_id);
		}}

		catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return true;
	}


	public Customer findOne(String mobileNumber) {

		//return data.get(mobileNumber);
		try {
			String jdbcDriver="com.mysql.jdbc.Driver";
			Class.forName(jdbcDriver);


		String jdbcURL = "jdbc:mysql://localhost:3306/test";

		Connection dbConnection = DriverManager.getConnection(jdbcURL);
		Statement stmt=dbConnection.createStatement();
			Statement selectStatement = dbConnection.createStatement(
					ResultSet.TYPE_FORWARD_ONLY,ResultSet.CONCUR_READ_ONLY);
			ResultSet rs=stmt.executeQuery("select * from Customer,Wallet where Customer.walletid=Wallet.walletid and Customer.mobileNumber=mobileNumber");
		
		}
		catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;	
	}





}
