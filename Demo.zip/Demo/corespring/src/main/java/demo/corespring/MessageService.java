package demo.corespring;

public class MessageService {
	private Message message;
	public void printmessage() 
	{
		System.out.println("Hello spring!");
	}
	public MessageService(Message message) {
		//super();
		this.message = message;
		System.out.println(message.getText());
	}
	

}
