package demo.corespring;

import org.springframework.context.support.GenericXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       // MessageService msg = new MessageService();
        //msg.printmessage();
    	GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("demo/corespring/beanconfig.xml");
    	MessageService service = ctx.getBean("msg", MessageService.class);
    	//MessageService service1 = ctx.getBean("msg", MessageService.class);
    	service.printmessage();
    	//System.out.println(service == service1);
    	//if(service == service1)
    	//System.out.println(((String) ctx).getText());
    	//System.out.println(message.getText());
    }
}
