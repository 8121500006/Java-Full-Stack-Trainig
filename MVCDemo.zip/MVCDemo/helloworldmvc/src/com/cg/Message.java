package com.cg;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RestController;

@RestController
//@Controller
public class Message {
	private String data;

	public Message(String data) {
		super();
		this.data = data;
	}

	public Message() {
		super();
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}
	

}
