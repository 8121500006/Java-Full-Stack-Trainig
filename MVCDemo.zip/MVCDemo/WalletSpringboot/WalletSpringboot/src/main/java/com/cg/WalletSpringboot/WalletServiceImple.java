package com.cg.WalletSpringboot;

//package demo.Base_App_SPData;


import java.sql.SQLException;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//import demo.beans.Customer;
//import demo.beans.Wallet;
//import demo.repo.WalletRepoInterface;

@Service(value="service")
public class WalletServiceImple implements WalletServiceInterface{
	
	@Autowired
	private WalletRepoInterface repo;
	
	@Transactional
	
	public Customer createAccount(Customer c) throws ClassNotFoundException, SQLException{
		
		
		Customer c1 = repo.save(c);
	    return c1;
			
	}
	public Customer showBalance(String mobileNumber) {
		return repo.findOne(mobileNumber);
		
	}
	
	@Transactional
	public Customer deposit(String mobileNumber, float amount) {
		Customer c;
		Wallet w ;
		 c = repo.findOne(mobileNumber);
		  w = c.getWallet();
		    float currentbalance = w.getBalance();
		    currentbalance = currentbalance + amount;
		    
		    w.setBalance(currentbalance);
		    c.setWallet(w);
		    repo.save(c);
		   // repo.save(mobileNumber,currentbalance);
		return c;
	}

@Transactional
	public boolean withdraw(String mobileNumber, float amount) {
		// TODO Auto-generated method stub
		
		Customer c ;
		Wallet w ;
		 c = repo.findOne(mobileNumber);
		
	    w = c.getWallet();
	    float balance = w.getBalance();
		if(amount > balance)
		{			return false;
		}
	    
		balance = balance - amount;
		
	    w.setBalance(balance);
	    c.setWallet(w);
	   // repo.update(mobileNumber,balance);
	   
		return true;
		 
	}



}
