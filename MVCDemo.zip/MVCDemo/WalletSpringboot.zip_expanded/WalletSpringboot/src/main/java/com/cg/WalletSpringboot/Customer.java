package com.cg.WalletSpringboot;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

//package demo.Base_App_SPData;

/*import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
*/
@Entity
public class Customer {
	@Id
	private int id;
	//private Transaction transactions[];
	public Customer(int id) {
		super();
		this.id = id;
	}

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	private String name;
	private String mobileNumber;
	@OneToOne(cascade=CascadeType.ALL)
	Wallet wallet;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public Wallet getWallet() {
		return wallet;
	}
	public void setWallet(Wallet wallet) {
		this.wallet = wallet;
	}
	
public String toString(){
	return name+" "+mobileNumber+" "+wallet.getBalance();
}
}
