Title:
------------

Core JAVAScript Language

(
	Ref: Head First JAVAScript
	Chapter#5	Looping
) 

Notes:
--------

JAVAScript supports iteration statements:
	for loop; while loop

break and continue can be used in loops to control behavior.

array is an object created using new operator.
arrays can contain values from different types
two dimensional arrays ; is an array of an array
ragged arrays are supported

logical operators are:
	&& and
	|| or
	! not
